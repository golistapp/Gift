document.addEventListener('DOMContentLoaded', () => {
    // Memory ID from URL
    const urlParams = new URLSearchParams(window.location.search);
    const memoryId = urlParams.get('id') || 'TEST_MEMORY_001'; 

    // --- 1. IMAGE PREVIEW LOGIC (Now 5 Images) ---
    const imageInputs = [
        { input: document.getElementById('image1'), preview: document.getElementById('preview1'), file: null },
        { input: document.getElementById('image2'), preview: document.getElementById('preview2'), file: null },
        { input: document.getElementById('image3'), preview: document.getElementById('preview3'), file: null },
        { input: document.getElementById('image4'), preview: document.getElementById('preview4'), file: null },
        { input: document.getElementById('image5'), preview: document.getElementById('preview5'), file: null }
    ];

    imageInputs.forEach(item => {
        item.input.addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                item.file = file; 
                const reader = new FileReader();
                reader.onload = function(event) { item.preview.src = event.target.result; }
                reader.readAsDataURL(file);
            }
        });
    });

    // --- 2. WARNING MODAL LOGIC ---
    const triggerBtn = document.getElementById('trigger-warning-btn');
    const warningModal = document.getElementById('warning-modal');
    const cancelBtn = document.getElementById('cancel-submit');
    const confirmBtn = document.getElementById('confirm-submit');
    const memoryForm = document.getElementById('memory-form');

    triggerBtn.addEventListener('click', () => {
        if (memoryForm.checkValidity()) {
            // Check if all 5 images are uploaded
            const allUploaded = imageInputs.every(item => item.file !== null);
            if (!allUploaded) {
                alert("Please upload all 5 photos before locking the gift!");
                return;
            }
            warningModal.classList.remove('hidden');
        } else {
            memoryForm.reportValidity();
        }
    });

    cancelBtn.addEventListener('click', (e) => {
        e.preventDefault();
        warningModal.classList.add('hidden');
    });

    // --- 3. COMPRESSION & UPLOAD ---
    async function compressImage(file) {
        const options = { maxSizeMB: 1, maxWidthOrHeight: 1200, useWebWorker: true, initialQuality: 0.4 };
        try { return await imageCompression(file, options); } 
        catch (error) { return file; }
    }

    async function uploadToImageKit(file, fileName) {
        const formData = new FormData();
        formData.append("file", file);
        formData.append("fileName", fileName);
        formData.append("folder", "/qr-memory-gift"); 
        const authHeader = "Basic " + btoa(IMAGEKIT_CONFIG.privateKey + ":");
        const response = await fetch("https://upload.imagekit.io/api/v1/files/upload", {
            method: "POST", headers: { "Authorization": authHeader }, body: formData
        });
        if (!response.ok) throw new Error("Upload failed");
        const data = await response.json();
        return data.url; 
    }

    // --- 4. FIREBASE SAVE ---
    async function saveToFirebase(memoryId, memoryData) {
        const firebaseUrl = `${firebaseConfig.databaseURL}/memories/${memoryId}.json`;
        const response = await fetch(firebaseUrl, {
            method: 'PATCH', 
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(memoryData)
        });
        if (!response.ok) throw new Error("Firebase save failed!");
        return await response.json();
    }

    // --- 5. FINAL SUBMIT LOGIC ---
    confirmBtn.addEventListener('click', async (e) => {
        e.preventDefault();
        confirmBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Processing...';
        confirmBtn.disabled = true;
        cancelBtn.disabled = true;

        try {
            // Collect Text Data
            const gfName = document.getElementById('gf-name').value;
            const passcode = document.getElementById('passcode-input').value;
            const musicId = document.getElementById('music-select').value;
            const letterText = document.getElementById('letter-text').value;
            
            // Collect Open When Messages
            const owHappy = document.getElementById('ow-happy').value;
            const owSad = document.getElementById('ow-sad').value;
            const owMissMe = document.getElementById('ow-miss-me').value;
            const owCantSleep = document.getElementById('ow-cant-sleep').value;

            // Collect Captions
            const captions = [
                document.getElementById('caption1').value,
                document.getElementById('caption2').value,
                document.getElementById('caption3').value,
                document.getElementById('caption4').value,
                document.getElementById('caption5').value
            ];

            const finalImageUrls = [];

            // Compress and Upload 5 Images
            for (let i = 0; i < 5; i++) {
                const fileName = `memory_${memoryId}_img${i+1}.jpg`;
                const compressedFile = await compressImage(imageInputs[i].file);
                const uploadedUrl = await uploadToImageKit(compressedFile, fileName);
                finalImageUrls.push(uploadedUrl);
            }

            // Prepare Data Object for Firebase
            const memoryData = {
                girlfriend_name: gfName,
                passcode: passcode,
                music_id: musicId,
                message_text: letterText,
                
                // Open When Cards
                open_when_happy: owHappy,
                open_when_sad: owSad,
                open_when_miss_me: owMissMe,
                open_when_cant_sleep: owCantSleep,

                // 5 Photos
                image_1_url: finalImageUrls[0], caption_1: captions[0],
                image_2_url: finalImageUrls[1], caption_2: captions[1],
                image_3_url: finalImageUrls[2], caption_3: captions[2],
                image_4_url: finalImageUrls[3], caption_4: captions[3],
                image_5_url: finalImageUrls[4], caption_5: captions[4],
                
                updated_at: new Date().toISOString(),
                status: "locked" 
            };

            // Save to Firebase
            await saveToFirebase(memoryId, memoryData);

            alert("Gift Locked Successfully! ❤️ Girlfriend ab QR scan karke isse dekh sakti hai.");
            warningModal.classList.add('hidden');
            document.querySelectorAll('input, textarea, select, button').forEach(el => el.disabled = true);
            confirmBtn.innerText = "Gift Locked!";

        } catch (error) {
            console.error("Submission Error:", error);
            alert("Oops! Kuch problem hui. Console check karein.");
            confirmBtn.innerText = "Yes, Lock Gift";
            confirmBtn.disabled = false;
            cancelBtn.disabled = false;
        }
    });
});
